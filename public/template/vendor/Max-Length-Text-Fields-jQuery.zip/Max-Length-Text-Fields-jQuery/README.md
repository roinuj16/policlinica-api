# jQuery maxlength Plugin

## Usage

```html
<script type="text/JavaScript" src="path/to/jquery.maxlength.js" />
```
	
Use it like:

```js
$("#myElementId").maxlength(/*options*/);
```
